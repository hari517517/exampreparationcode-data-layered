namespace CodeFirstNewDatabase
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class DemoModel : DbContext
    {
        
        public DemoModel()
            : base("name=DemoModel")
        {
        }

        public virtual DbSet<Product> Products { get; set; }
        
    }

    //public class MyEntity
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //}
}